from pymongo import MongoClient

class Mongo:
	def __init__(self):
		self.cliente = MongoClient('localhost',27017)#('mongodb://3.17.13.219:27017/')
		self.db = self.cliente.ZOHO # eligiendo base
		self.db_user = self.cliente.Usuario # eligiendo base usuarios
		self.coleccion_user = self.db_user.usuarios # eligiendo coleccion usuarios
		self.coleccion_admin = self.db_user.admin # eligiendo coleccion admin
		self.coleccion = self.db.datos # eligiendo coleccion

	def subir(self,datos=None):
		if not datos:
			return
		n_obj = self.coleccion.find()
		datos['_id'] = n_obj.count() + 1
		data = self.coleccion.insert_one(datos)
		x = self.coleccion.find({'msg':'hola mundo','valor':{ "$gt": 100 }},{'_id':0})

	def adquirirToken(self,doc):
		reg = self.coleccion_user.find_one(doc,{'token':1})
		if reg:
			return {'flag':True,'token':reg['token']}
		return {'flag':False,'token':None}

	def validar(self,token):
		reg = self.coleccion_user.find_one({'token':token})
		if reg:
			return True
		return False