import requests as req,os
class API:
	def __init__(self):
		self.client_id = '1000.JGEAZ4G55499L6ORKETJZ0F4GDDKQB'
		self.client_secret = '4d46f262b34efcdb7d0e82c17878436d86417e01de'
		self.token_refresh = '1000.1b137b644a01c655fca93cd9b77b72ce.a35622f865b72a89f4354880d49e114b'
		f = open('utilidades/credencial.txt')
		self.token = f.read()
		f.close()
		self.url = 'https://www.zohoapis.com/crm/v2/Leads/upsert'
		self.url_auth = 'https://accounts.zoho.com/oauth/v2/token'
		self.data_zoho = {'data':None,'trigger':["approval","workflow","blueprint"]}
	def send(self,data):
		if type(data) == dict:
			self.data_zoho['data'] = [self.reorganiza(data)]
		elif type(data) == list:
			self.data_zoho['data'] = [self.reorganiza(data)]
		#return (True,self.data_zoho)
		pet_env = req.post(self.url,json=self.data_zoho,headers={'Authorization':'Zoho-oauthtoken '+self.token})
		if pet_env.status_code != 200:
			self.actualizar_token()
			pet_env = req.post(self.url,json=self.data_zoho,headers={'Authorization':'Zoho-oauthtoken '+self.token})
			if pet_env.status_code != 200:
				return (False,pet_env.json())
		else:
			return(False,pet_env.json())
		return (True,pet_env.json())
	def actualizar_token(self):
		url = self.url_auth +f'?refresh_token={self.token_refresh}&client_id={self.client_id}&client_secret={self.client_secret}&grant_type=refresh_token'
		pet = req.post(url)
		if pet.status_code == 200:
			self.token = pet.json()['access_token']
			f = open('utilidades/credencial.txt','w')
			f.write(self.token)
			f.close()
	def reorganiza(self,datos):
		l_ren = ['PRIMER NOMBRE','PRIMER APELLIDO','Nu00DAMERO DE IDENTIFICACIu00D3N',\
				'CORREO ELECTRONICO','CELULAR','DEPARTAMENTO DE RESIDENCIA']
		l_nam = ['Name','Last_Name','Cedula','Email','Phone','Dpto']
		data = {}
		for e in datos:
			data[e['label']] = e['value']
		for e in range(len(l_ren)):
			if data.get(l_ren[e]):
				data[l_nam[e]] = data.pop(l_ren[e])
		data['Name'] = data['Name']+ ' ' + data.pop('SEGUNDO NOMBRE')
		data['Last_Name'] = data['Last_Name']+ ' ' + data.pop('SEGUNDO APELLIDO')
		return data