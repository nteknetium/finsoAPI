import random,base64

class Token:
	def __init__(self):
		print('creando instancia')
	def generar(self,max_len=15):
		gen = ''
		print(max_len)
		for i in range(max_len):
			gen += chr(random.randint(1,256))
		gen = base64.b64encode(gen.encode()).decode()
		print(gen)
		return gen
