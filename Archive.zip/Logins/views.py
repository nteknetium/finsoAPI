from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from utilidades.Tokens import Token
from utilidades.BaseDatos import Mongo
from utilidades.API import API
import json

# Create your views here.
@csrf_exempt
def login(request):
	if request.method == 'POST':
		recv = json.loads(request.body) #adquiere el json enviado
		try:
			db = Mongo() # crea la instancia cliente a mongoDB
			reg = {'email':recv['email'],'passw':recv['passw'],'cliente_id':recv['clientId']} # reforma la estructura de los datos
			resp = db.adquirirToken(reg) # validando datos y devolviendo token
			if resp['flag']: # si esta registrado devuelve el token
				return JsonResponse({'code':200,'token':resp['token']})
			return JsonResponse({'code':401,'msg':'Unauthorized'}) # error no autorizado
		except KeyError as Err:
			return JsonResponse({'msg':f'error en clave {Err}','code':406}) # error con la estructura de datos
	return JsonResponse({'msg':'Method Not Allowed','code':405}) # error metodo no permitido

@csrf_exempt
def subir(request):
	if request.method == 'POST':
		recv = json.loads(request.body) #adquiere el json enviado
		try:
			db = Mongo() # crea la instancia cliente a mongoDB
			res = db.validar(recv['token'])  # se valida el token enviado
			print(res)

			if not res: # si no hay coincidencia devuelve error
				return JsonResponse({'msg':'Unauthorized ','code':401})
			datos = recv.get('datos')
			if datos:  # se valida si se envio datos para subir
				cliente = API()
				resp = cliente.send(datos)
				return JsonResponse(resp[1])
				#return JsonResponse({'msg':'datos guardados!','code':200})
			else:  # sino devuelve error
				return JsonResponse({'msg':'Not Acceptable','error':406})
		except KeyError as Err:  # si ocurre algun problema con la estructura de datos
			return JsonResponse({'msg':'error en datos','code':406})
	return JsonResponse({'msg':'Method Not Allowed','code':405})  # error metodo equivocado

"""
#funciones admin
def crear(data):
	if not data:
		return {'error':1,'msg':'error data'}
	try:
		gen_token = Token()
		reg = Usuarios()
		reg.email = data['email']
		reg.passw = data['passw']
		reg.client_id = data['clientId']
		reg.permiso = 1
		reg.token = gen_token.generar()
		reg.save()
		return {'msg':'OK','error':0}
	except KeyError as Err:
		return {'msg':'error datos incompletos','error':1}

def listar(data):
	res = list(Usuarios.objects.filter(permiso=1).values())
	return {'data':res}
	return {'msg':'OK','error':0}
def eliminar(data):
	if not data:
		return {'error':1,'msg':'error data'}
	try:
		res = Usuarios.objects.filter(id=data['id'])
		if res.count() >0:
			res.delete()
			return {'msg':'OK','error':0}
		else:
			return {'msg':'no habia coincidencias','error':0}
	except KeyError as Err:
		return {'msg':'error datos incompletos','error':1}
def actualizar(data):
	if not data:
		return {'error':1,'msg':'error data'}
	try:
		reg = Usuarios.objects.get(id=data['id'])
		reg.email = data['email']
		reg.passw = data['passw']
		reg.client_id = data['clientId']
		reg.save()
		return {'msg':'OK','error':0}
	except KeyError as Err:
		return {'msg':'error datos incompletos','error':1}
@csrf_exempt
def admin(request):
	if request.method == 'POST':
		recv = json.loads(request.body)
		token_admin = Usuarios.objects.get(permiso=3).token
		token = recv.get('token','')
		if token == '':
			return JsonResponse({'error':1,'msg':'Peticion no valida!'})
		if token != token_admin:
			return JsonResponse({'error':1,'msg':'error de validacion'})
		opciones = ['crear','listar','eliminar','actualizar']
		func = [crear,listar,eliminar,actualizar]
		op = recv.get('op','')
		if op in opciones:
			resp = func[opciones.index(op)](recv.get('data'))
		else:
			return JsonResponse({'error':1,'msg':'Operacion no valida!'})
		return JsonResponse(resp)"""
		