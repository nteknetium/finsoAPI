from django.db import models

# Create your models here.
class Usuarios(models.Model):
	email = models.TextField()
	passw = models.CharField(max_length=50)
	client_id = models.CharField(max_length=50)
	token = models.CharField(max_length=50)
	permiso = models.IntegerField(default=1)