from django.urls import path
from .views import login,subir

urlpatterns = [
	path('login',login),
	path('subir',subir),
	#path('admin',admin)
]